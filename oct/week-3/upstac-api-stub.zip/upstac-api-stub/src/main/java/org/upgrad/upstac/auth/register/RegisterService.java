package org.upgrad.upstac.auth.register;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.stereotype.Service;
import org.upgrad.upstac.exception.AppException;
import org.upgrad.upstac.users.User;
import org.upgrad.upstac.users.UserService;
import org.upgrad.upstac.users.roles.UserRole;


@Service
public class RegisterService {

    @Autowired
    private UserService userService;


    private static final Logger log = LoggerFactory.getLogger(RegisterService.class);


    public User addUser(RegisterRequest registerRequest) {





/*      User should be validated before registration.
                the username , email and phone number should be unique (i.e should throw AppException if the RegisterRequest has the same username or email or phone number)
                    hint:
                        userService.findByUserName
                        userService.findByEmail
                        userService.findByPhoneNumber

         A new User Object should be created with same details as registerRequest
                password should be encrypted with help of   userService.toEncrypted
                roles should be set with help of  userService.getRoleFor(UserRole.USER)
                status should be set to AccountStatus.APPROVED

        And finally
            Call userService.saveInDatabase to save the new user and return the saved user
*/
      if(isUserAlreadyRegistered(registerRequest.getUserName(),registerRequest.getEmail(),registerRequest.getPhoneNumber())) {
          registerRequest.setPassword(userService.toEncrypted(registerRequest.getPassword()));
          return userService.saveInDatabase(userService.addUser(registerRequest));
      }else {
          throw new InvalidDataAccessApiUsageException("User Already Registered");
      }
    }

    public User addDoctor(RegisterRequest user) {


/*      Doctor should be validated before registration.
                the username , email and phone number should be unique (i.e should throw AppException if the RegisterRequest has the same username or email or phone number)
                    hint:
                        userService.findByUserName
                        userService.findByEmail
                        userService.findByPhoneNumber

         A new User Object should be created with same details as registerRequest
                password should be encrypted with help of   userService.toEncrypted
                roles should be set with help of  userService.getRoleFor(UserRole.DOCTOR)
                status should be set to AccountStatus.INITIATED

        And finally
            Call userService.saveInDatabase to save the newly registered doctor and return the saved value
*/
        if(isUserAlreadyRegistered(user.getUserName(),user.getEmail(),user.getPhoneNumber())) {
            user.setPassword(userService.toEncrypted(user.getPassword()));
            return userService.saveInDatabase(userService.addDoctor(user));
        }else {
            throw new InvalidDataAccessApiUsageException("Dcotor Already Registered");
        }
    }


    public User addTester(RegisterRequest user) {


/*      Tester should be validated before registration.
                the username , email and phone number should be unique (i.e should throw AppException if the RegisterRequest has the same username or email or phone number)
                    hint:
                        userService.findByUserName
                        userService.findByEmail
                        userService.findByPhoneNumber

         A new User Object should be created with same details as registerRequest
                password should be encrypted with help of   userService.toEncrypted
                roles should be set with help of  userService.getRoleFor(UserRole.TESTER)
                status should be set to AccountStatus.INITIATED

        And finally
            Call userService.saveInDatabase to save newly registered tester and return the saved value
*/

        if(isUserAlreadyRegistered(user.getUserName(),user.getEmail(),user.getPhoneNumber())) {
            user.setPassword(userService.toEncrypted(user.getPassword()));
            return userService.saveInDatabase(userService.addTester(user));
        }else {
            throw new InvalidDataAccessApiUsageException("Tester Already Registered");
        }
    }

    private Boolean isUserAlreadyRegistered(String userName,String email,String phoneNumber){

       if(userService.findByUserName(userName) != null){
           return Boolean.TRUE;
       }

        if(userService.findByEmail(email) != null){
            return Boolean.TRUE;
        }

        if(userService.findByPhoneNumber(phoneNumber) != null){
            return Boolean.TRUE;
        }
      return Boolean.FALSE;
    }

}
